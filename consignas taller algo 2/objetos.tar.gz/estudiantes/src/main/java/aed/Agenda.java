package aed;

import java.util.Vector;

public class Agenda {

    public Agenda(Fecha fechaActual) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public void agregarRecordatorio(Recordatorio recordatorio) {
        throw new UnsupportedOperationException("No implementada aun");

    }

    @Override
    public String toString() {
        throw new UnsupportedOperationException("No implementada aun");

    }

    public void incrementarDia() {
        throw new UnsupportedOperationException("No implementada aun");

    }

    public Fecha fechaActual() {
        throw new UnsupportedOperationException("No implementada aun");
    }

}
